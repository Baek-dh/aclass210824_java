package edu.kh.control.condition.ex.run;

import edu.kh.control.condition.ex.service.ConditionService;
import edu.kh.control.condition.ex.service.ConditionService2;


public class CondtionRun {
	public static void main(String[] args) {
		
		ConditionService service = new ConditionService();
		
//		service.example1();
//		service.example2();
//		service.example3();
//		service.example4();
//		service.example5();
//		service.example6();
//		service.example7();
//		service.example8();
		
		
		ConditionService2 service2 = new ConditionService2();
		service2.example1();
		
		
		
		
	}
}
